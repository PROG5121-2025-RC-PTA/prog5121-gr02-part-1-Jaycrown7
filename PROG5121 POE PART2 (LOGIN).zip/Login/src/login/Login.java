package login;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;

public class Login {

    public static String registeredUsername = "";
    public static String registeredPassword = "";
    public static boolean isLoggedIn = false;
    public static List<JSONObject> sentMessages = new ArrayList<>();
    public static int messageCount = 0;

    public static void main(String[] args) {

        UIManager.put("OptionPane.background", new Color(237, 240, 255));
        UIManager.put("Panel.background", new Color(230, 240, 255));
        UIManager.put("OptionPane.messageForeground", new Color(0, 51, 102));
        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 14));

        // REGISTRATION
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String phone = JOptionPane.showInputDialog("Enter phone number (+27...):");

        if (!checkUsername(username)) return;
        registeredUsername = username;

        if (!checkPasswordComplexity(password)) return;
        registeredPassword = password;

        if (!checkCellPhoneNumber(phone)) return;

        JOptionPane.showMessageDialog(null, "All details successfully captured. Proceeding to login...");

        // LOGIN
        String loginUsername = JOptionPane.showInputDialog("Enter username to login:");
        String loginPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (loginUsername.equals(registeredUsername) && loginPassword.equals(registeredPassword)) {
            isLoggedIn = true;
            JOptionPane.showMessageDialog(null, "Login successful. Welcome " + loginUsername + "!");
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Username or password incorrect.");
            return;
        }

        // MAIN MENU
        if (isLoggedIn) {
            JOptionPane.showMessageDialog(null, "Welcome to Quickchat");

            while (true) {
                String menuOption = JOptionPane.showInputDialog(
                        "Choose an option:\n1. Send messages\n2. Show recently sent messages\n3. Quit");

                if (menuOption == null) break;

                switch (menuOption) {
                    case "1":
                        int toSend = 0;
                        try {
                            toSend = Integer.parseInt(JOptionPane.showInputDialog("How many messages do you want to send now?"));
                        } catch (Exception e) {
                            JOptionPane.showMessageDialog(null, "Invalid number.");
                            break;
                        }

                        for (int i = 0; i < toSend; i++) {
                            String result = SentMessage();
                            if (result.equals("sent")) {
                                // Message counted inside SentMessage
                            }
                        }
                        break;

                    case "2":
                        JOptionPane.showMessageDialog(null, "Coming soon");
                        break;

                    case "3":
                        JOptionPane.showMessageDialog(null, "Goodbye!");
                        return;

                    default:
                        JOptionPane.showMessageDialog(null, "Invalid option.");
                }
            }
        }
    }

    // VALIDATION METHODS
    public static boolean checkUsername(String username) {
        if (!username.contains("_") || username.length() > 5) {
            JOptionPane.showMessageDialog(null, "Username must contain _ and be max 5 characters.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Username successfully captured.");
        return true;
    }

    public static boolean checkPasswordComplexity(String password) {
        if (password.length() < 8 ||
                !password.matches(".*[A-Z].*") ||
                !password.matches(".*[0-9].*") ||
                !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            JOptionPane.showMessageDialog(null, "Password must be at least 8 characters and include uppercase, number, and special character.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Password successfully captured.");
        return true;
    }

    public static boolean checkCellPhoneNumber(String phone) {
        if (!phone.matches("^\\+\\d{1,4}\\d{1,10}$")) {
            JOptionPane.showMessageDialog(null, "Phone number must start with country code like +27 and be valid.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Cell phone number successfully added.");
        return true;
    }

    // 

    public static boolean checkMessageId(String id) {
        return id.length() <= 10;
    }

    public static int checkRecipientCell(String cell) {
        if (cell.length() == 10 && cell.startsWith("0")) {
            return 1;
        }
        return 0;
    }

    public static String createMessageHash(String message) {
        return Integer.toString(message.hashCode());
    }

    public static String SentMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient number (must start with 0):");
        if (checkRecipientCell(recipient) == 0) {
            JOptionPane.showMessageDialog(null, "Invalid recipient number.");
            return "fail";
        }

        String messageText = JOptionPane.showInputDialog("Enter your message:");
        String messageID = UUID.randomUUID().toString().substring(0, 10);

        if (!checkMessageId(messageID)) {
            JOptionPane.showMessageDialog(null, "Message ID too long.");
            return "fail";
        }

        String[] options = {"Send Now", "Disregard", "Store for Later"};
        int choice = JOptionPane.showOptionDialog(null, "Choose:", "Message Option", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            storeMessage(messageID, recipient, messageText);
            JOptionPane.showMessageDialog(null, "Message sent and saved.");
            return "sent";
        } else if (choice == 1) {
            JOptionPane.showMessageDialog(null, "Message disregarded.");
            return "disregarded";
        } else if (choice == 2) {
            JOptionPane.showMessageDialog(null, "Feature to store for later is under development.");
            return "stored";
        }

        return "fail";
    }

    public static void storeMessage(String id, String recipient, String message) {
        JSONObject msg = new JSONObject();
        msg.put("id", id);
        msg.put("recipient", recipient);
        msg.put("message", message);
        msg.put("hash", createMessageHash(message));

        sentMessages.add(msg);
        JSONArray jsonArray = new JSONArray(sentMessages);

        try (FileWriter file = new FileWriter("messages.json")) {
            file.write(jsonArray.toString(4));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving message: " + e.getMessage());
        }

        messageCount++;
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) return "No messages sent yet.";
        StringBuilder sb = new StringBuilder();
        for (JSONObject msg : sentMessages) {
            sb.append("To: ").append(msg.getString("recipient"))
              .append("\nMessage: ").append(msg.getString("message"))
              .append("\nHash: ").append(msg.getString("hash")).append("\n\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return messageCount;
    }
}



