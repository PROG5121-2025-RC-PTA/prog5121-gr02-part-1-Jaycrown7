package grades;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class StudentManagerTest {

    private StudentManager manager;

    @Before
    public void setUp() {
        manager = new StudentManager(10);
        manager.addStudent(new UndergraduateStudent("U001", "Alice", 2, new int[]{60, 70, 80}));
        manager.addStudent(new GraduateStudent("G001", "Bob", "AI", new int[]{58, 62, 65}));
    }

    @Test
    public void testAddAndFindStudent() {
        assertNotNull(manager.findById("U001"));
        assertNotNull(manager.findById("G001"));
    }

    @Test
    public void testFindStudent_NotFound() {
        assertNull(manager.findById("X999"));
    }

    @Test
    public void testUpdateName() {
        boolean ok = manager.updateName("U001", "Alice Cooper");
        assertTrue(ok);
        assertEquals("Alice Cooper", manager.findById("U001").getName());
    }

    @Test
    public void testDeleteStudent() {
        boolean ok = manager.deleteById("U001");
        assertTrue(ok);
        assertNull(manager.findById("U001"));
    }

    @Test
    public void testDeleteStudent_NotFound() {
        assertFalse(manager.deleteById("XYZ"));
    }

    @Test
    public void testAveragesAndPassFail() {
        Student u = manager.findById("U001"); // avg = 70 -> pass (>=50)
        Student g = manager.findById("G001"); // avg ≈ 61.67 -> pass for grad (>=60)
        assertEquals(70.0, u.average(), 0.001);
        assertTrue(u.hasPassed());
        assertTrue(g.hasPassed());
    }

    @Test
    public void testTopStudent() {
        Student top = manager.getTopStudent();
        assertNotNull(top);
        assertEquals("Alice", top.getName()); // 70 avg vs ~61.67 avg
    }

    @Test
    public void testClassAverage() {
        double classAvg = manager.getClassAverage(); // (70 + 61.6667) / 2 = 65.8333
        assertEquals(65.8333, classAvg, 0.01);
    }
}

