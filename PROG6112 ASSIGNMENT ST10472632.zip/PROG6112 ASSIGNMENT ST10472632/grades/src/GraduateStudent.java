package grades;

public class GraduateStudent extends Student {
    private String researchTopic;

    public GraduateStudent(String id, String name, String researchTopic, int[] marks) {
        super(id, name, marks);
        this.researchTopic = researchTopic == null ? "" : researchTopic;
    }

    public String getResearchTopic() { return researchTopic; }
    public void setResearchTopic(String researchTopic) { this.researchTopic = researchTopic; }

    @Override
    protected int getPassMark() {
        return 60; // stricter for grads
    }

    @Override
    public String summaryLine() {
        return super.summaryLine() + String.format(" | Grad Topic: %s", researchTopic);
    }
}

