package grades;

import java.util.Arrays;

public class Student {
    private String id;
    private String name;
    private int[] marks; // array of subject marks

    public Student() {
        this("", "", new int[0]);
    }

    public Student(String id, String name, int[] marks) {
        this.id = id;
        this.name = name;
        setMarks(marks);
    }

    // --- Encapsulation ---
    public String getId() { return id; }
    public void setId(String id) { if (id != null) this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { if (name != null) this.name = name; }

    public int[] getMarks() { return Arrays.copyOf(marks, marks.length); }
    public void setMarks(int[] marks) {
        if (marks == null) {
            this.marks = new int[0];
        } else {
            this.marks = Arrays.copyOf(marks, marks.length); // defensive copy
        }
    }

    // --- Behavior ---
    public double average() {
        if (marks.length == 0) return 0.0;
        int sum = 0;
        for (int m : marks) sum += m;
        return sum / (double) marks.length;
    }

    /** Default pass mark (UG = 50). Subclasses can override. */
    protected int getPassMark() {
        return 50;
    }

    public boolean hasPassed() {
        return average() >= getPassMark();
    }

    public String summaryLine() {
        return String.format("%s | %-15s | Avg: %.2f | Passed: %s",
                id, name, average(), hasPassed() ? "Yes" : "No");
    }
}

