package grades;

import java.util.Scanner;

public class MainGrades {
    private static final Scanner sc = new Scanner(System.in);
    private static final StudentManager manager = new StudentManager(100);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n=== STUDENT GRADE MANAGER ===");
            System.out.println("(1) Add Undergraduate");
            System.out.println("(2) Add Graduate");
            System.out.println("(3) Search by ID");
            System.out.println("(4) Update name");
            System.out.println("(5) Delete by ID");
            System.out.println("(6) Print report");
            System.out.println("(7) Exit");
            System.out.print("Choice: ");
            String choice = sc.nextLine().trim();

            switch (choice) {
                case "1": addUndergrad(); break;
                case "2": addGraduate(); break;
                case "3": search(); break;
                case "4": updateName(); break;
                case "5": delete(); break;
                case "6": manager.printReport(); break;
                case "7": System.out.println("Bye!"); return;
                default: System.out.println("Invalid choice.");
            }
        }
    }

    private static void addUndergrad() {
        System.out.print("ID: "); String id = sc.nextLine();
        System.out.print("Name: "); String name = sc.nextLine();
        int year = readInt("Year of study (1-4): ");
        int[] marks = readMarks();
        boolean ok = manager.addStudent(new UndergraduateStudent(id, name, year, marks));
        System.out.println(ok ? "Undergraduate added." : "Failed (duplicate ID or capacity reached).");
    }

    private static void addGraduate() {
        System.out.print("ID: "); String id = sc.nextLine();
        System.out.print("Name: "); String name = sc.nextLine();
        System.out.print("Research Topic: "); String topic = sc.nextLine();
        int[] marks = readMarks();
        boolean ok = manager.addStudent(new GraduateStudent(id, name, topic, marks));
        System.out.println(ok ? "Graduate added." : "Failed (duplicate ID or capacity reached).");
    }

    private static void search() {
        System.out.print("Enter ID: "); String id = sc.nextLine();
        Student s = manager.findById(id);
        System.out.println(s == null ? "Not found." : s.summaryLine());
    }

    private static void updateName() {
        System.out.print("Enter ID: "); String id = sc.nextLine();
        System.out.print("New name: "); String name = sc.nextLine();
        boolean ok = manager.updateName(id, name);
        System.out.println(ok ? "Updated." : "No student with that ID.");
    }

    private static void delete() {
        System.out.print("Enter ID: "); String id = sc.nextLine();
        boolean ok = manager.deleteById(id);
        System.out.println(ok ? "Deleted." : "No student with that ID.");
    }

    private static int[] readMarks() {
        int n = readInt("How many subjects? ");
        int[] marks = new int[Math.max(0, n)];
        for (int i = 0; i < marks.length; i++) {
            marks[i] = readInt("Mark " + (i + 1) + " (0-100): ", 0, 100);
        }
        return marks;
    }

    private static int readInt(String prompt) {
        while (true) {
            try {
                System.out.print(prompt);
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Enter a valid number.");
            }
        }
    }

    private static int readInt(String prompt, int min, int max) {
        while (true) {
            int v = readInt(prompt);
            if (v < min || v > max) {
                System.out.printf("Enter a value between %d and %d.%n", min, max);
            } else return v;
        }
    }
}

