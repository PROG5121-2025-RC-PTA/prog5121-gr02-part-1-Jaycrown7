package grades;

public class UndergraduateStudent extends Student {
    private int yearOfStudy;

    public UndergraduateStudent(String id, String name, int yearOfStudy, int[] marks) {
        super(id, name, marks);
        this.yearOfStudy = yearOfStudy;
    }

    public int getYearOfStudy() { return yearOfStudy; }
    public void setYearOfStudy(int yearOfStudy) { this.yearOfStudy = yearOfStudy; }

    @Override
    public String summaryLine() {
        return super.summaryLine() + String.format(" | UG Year: %d", yearOfStudy);
    }
}

