package grades;

public class StudentManager {
    private final Student[] students;
    private int count = 0;

    public StudentManager(int capacity) {
        if (capacity <= 0) capacity = 1;
        this.students = new Student[capacity];
    }

    public int size() { return count; }
    public int capacity() { return students.length; }

    public boolean addStudent(Student s) {
        if (s == null || count >= students.length) return false;
        if (findById(s.getId()) != null) return false; // no duplicates
        students[count++] = s;
        return true;
    }

    public Student findById(String id) {
        if (id == null) return null;
        for (int i = 0; i < count; i++) {
            if (id.equals(students[i].getId())) return students[i];
        }
        return null;
    }

    public boolean updateName(String id, String newName) {
        Student s = findById(id);
        if (s == null) return false;
        s.setName(newName);
        return true;
    }

    public boolean deleteById(String id) {
        if (id == null) return false;
        for (int i = 0; i < count; i++) {
            if (id.equals(students[i].getId())) {
                // shift left
                for (int j = i; j < count - 1; j++) {
                    students[j] = students[j + 1];
                }
                students[count - 1] = null;
                count--;
                return true;
            }
        }
        return false;
    }

    public Student getTopStudent() {
        if (count == 0) return null;
        Student best = students[0];
        for (int i = 1; i < count; i++) {
            if (students[i].average() > best.average()) {
                best = students[i];
            }
        }
        return best;
    }

    public double getClassAverage() {
        if (count == 0) return 0.0;
        double sum = 0.0;
        for (int i = 0; i < count; i++) sum += students[i].average();
        return sum / count;
    }

    public int countPassed() {
        int c = 0;
        for (int i = 0; i < count; i++) if (students[i].hasPassed()) c++;
        return c;
    }

    public int countFailed() { return count - countPassed(); }

    public void printReport() {
        System.out.println("===== STUDENT REPORT 2025 =====");
        System.out.printf("Total: %d / %d | Passed: %d | Failed: %d | Class Avg: %.2f%n",
                count, students.length, countPassed(), countFailed(), getClassAverage());
        System.out.println("-----------------------------------------------");
        System.out.println("ID   | Name            | Type       | Avg  | Passed | Extra");
        System.out.println("-----------------------------------------------");
        for (int i = 0; i < count; i++) {
            Student s = students[i];
            String type = (s instanceof GraduateStudent) ? "Graduate" : "Undergrad";
            System.out.printf("%-4s | %-15s | %-10s | %4.1f | %-6s | ",
                    s.getId(), s.getName(), type, s.average(), s.hasPassed() ? "Yes" : "No");
            if (s instanceof GraduateStudent) {
                System.out.println("Topic: " + ((GraduateStudent) s).getResearchTopic());
            } else if (s instanceof UndergraduateStudent) {
                System.out.println("Year: " + ((UndergraduateStudent) s).getYearOfStudy());
            } else {
                System.out.println("-");
            }
        }
        Student top = getTopStudent();
        if (top != null) {
            System.out.printf("TOP STUDENT: %s (%s) | Avg: %.2f%n",
                    top.getName(), top.getId(), top.average());
        }
        System.out.println("===============================================");
    }
}

