package streaming;

import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class StreamingApplicationTest {

    private StreamingApplication app;

    @Before
    public void setUp() {
        app = new StreamingApplication();
        // Add a sample series before each test
        app.addSeries("S001", "Money Heist", "16", "20");
    }

    // TestSearchSeries()
    @Test
    public void TestSearchSeries() {
        SeriesModel result = app.findSeriesById("S001");
        assertNotNull("Series should be found", result);
        assertEquals("Money Heist", result.seriesName);
        assertEquals("16", result.seriesAge);
        assertEquals("20", result.seriesNumberOfEpisodes);
    }

    // TestSearchSeries_SeriesNotFound()
    @Test
    public void TestSearchSeries_SeriesNotFound() {
        SeriesModel result = app.findSeriesById("X999");
        assertNull("Series should not be found", result);
    }

    // TestUpdateSeries()
    @Test
    public void TestUpdateSeries() {
        boolean updated = app.updateSeriesDetails("S001", "Stranger Things", "12", "30");
        assertTrue("Series should be updated successfully", updated);

        SeriesModel updatedSeries = app.findSeriesById("S001");
        assertEquals("Stranger Things", updatedSeries.seriesName);
        assertEquals("12", updatedSeries.seriesAge);
        assertEquals("30", updatedSeries.seriesNumberOfEpisodes);
    }

    // TestDeleteSeries()
    @Test
    public void TestDeleteSeries() {
        boolean deleted = app.deleteSeries("S001");
        assertTrue("Series should be deleted successfully", deleted);

        SeriesModel result = app.findSeriesById("S001");
        assertNull("Series should no longer exist", result);
    }

    // TestDeleteSeries_SeriesNotFound()
    @Test
    public void TestDeleteSeries_SeriesNotFound() {
        boolean deleted = app.deleteSeries("X999");
        assertFalse("Deleting a non-existing series should return false", deleted);
    }

    // TestSeriesAgeRestriction_AgeValid()
    @Test
    public void TestSeriesAgeRestriction_AgeValid() {
        boolean valid = app.validateAge("15"); // valid range is 2–18
        assertTrue("Age restriction should be valid", valid);
    }

    // TestSeriesAgeRestriction_SeriesAgeInvalid()
    @Test
    public void TestSeriesAgeRestriction_SeriesAgelnValid() {
        boolean valid = app.validateAge("25"); // invalid because > 18
        assertFalse("Age restriction should be invalid", valid);
    }
}


