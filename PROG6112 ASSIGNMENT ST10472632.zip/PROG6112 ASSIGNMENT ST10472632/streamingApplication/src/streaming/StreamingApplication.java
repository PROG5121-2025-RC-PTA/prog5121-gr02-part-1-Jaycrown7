package streaming;

import java.util.ArrayList;

public class StreamingApplication {

    ArrayList<SeriesModel> seriesList = new ArrayList<>();

    public void addSeries(String id, String name, String age, String episodes) {
        seriesList.add(new SeriesModel(id, name, age, episodes));
    }

    public SeriesModel findSeriesById(String id) {
        for (SeriesModel s : seriesList) {
            if (s.seriesId.equals(id)) {
                return s;
            }
        }
        return null;
    }

    public boolean updateSeriesDetails(String id, String newName, String newAge, String newEpisodes) {
        SeriesModel s = findSeriesById(id);
        if (s != null) {
            if (validateAge(newAge) && validateEpisodes(newEpisodes)) {
                s.seriesName = newName;
                s.seriesAge = newAge;
                s.seriesNumberOfEpisodes = newEpisodes;
                return true;
            }
        }
        return false;
    }

    public boolean deleteSeries(String id) {
        SeriesModel s = findSeriesById(id);
        if (s != null) {
            seriesList.remove(s);
            return true;
        }
        return false;
    }

    public boolean validateAge(String age) {
        if (age.matches("\\d+")) {
            int numAge = Integer.parseInt(age);
            return numAge >= 2 && numAge <= 18;
        }
        return false;
    }

    public boolean validateEpisodes(String episodes) {
        return episodes.matches("\\d+");
    }

    public void printReport() {
        System.out.println("=== SERIES REPORT 2025 ===");
        for (SeriesModel s : seriesList) {
            System.out.println("ID: " + s.seriesId +
                    " | Name: " + s.seriesName +
                    " | Age Restriction: " + s.seriesAge +
                    " | Episodes: " + s.seriesNumberOfEpisodes);
        }
        System.out.println("==========================");
    }
}
