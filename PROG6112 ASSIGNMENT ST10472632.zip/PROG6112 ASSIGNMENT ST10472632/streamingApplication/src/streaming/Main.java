package streaming;

import java.util.Scanner;

public class Main {

    private static StreamingApplication app = new StreamingApplication();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            System.out.println("\nLATEST SERIES - 2025");
            System.out.println("*************************");
            System.out.println("Enter (1) to launch menu or any other key to exit");

            String launch = scanner.nextLine();
            if (!launch.equals("1")) {
                System.out.println("Exiting application...");
                break;
            }

            showMenu();
        }
    }

    private static void showMenu() {
        while (true) {
            System.out.println("\nPlease select one of the following menu items:");
            System.out.println("(1) Capture a new series");
            System.out.println("(2) Search for a series");
            System.out.println("(3) Update series details");
            System.out.println("(4) Delete a series");
            System.out.println("(5) Print series report - 2025");
            System.out.println("(6) Exit Application.");

            String choice = scanner.nextLine();

            switch (choice) {
                case "1":
                    captureSeries();
                    break;
                case "2":
                    searchSeries();
                    break;
                case "3":
                    updateSeries();
                    break;
                case "4":
                    deleteSeries();
                    break;
                case "5":
                    app.printReport();
                    break;
                case "6":
                    System.out.println("Exiting application...");
                    return;
                default:
                    System.out.println("Invalid choice, please try again.");
            }
        }
    }

    private static void captureSeries() {
        System.out.println("\nCAPTURE A NEW SERIES");
        System.out.println("*************************");

        System.out.print("Enter the series id: ");
        String id = scanner.nextLine();

        System.out.print("Enter the series name: ");
        String name = scanner.nextLine();

        String age;
        while (true) {
            System.out.print("Enter the series age restriction: ");
            age = scanner.nextLine();
            if (app.validateAge(age)) {
                break;
            } else {
                System.out.println("Incorrect series age! Enter between 2 and 18.");
            }
        }

        String episodes;
        while (true) {
            System.out.print("Enter the number of episodes for " + name + ": ");
            episodes = scanner.nextLine();
            if (app.validateEpisodes(episodes)) {
                break;
            } else {
                System.out.println("Invalid input. Please enter a number for episodes.");
            }
        }

        app.addSeries(id, name, age, episodes);
        System.out.println("Series processed successfully!");
    }

    private static void searchSeries() {
        System.out.print("Enter the series ID to search: ");
        String id = scanner.nextLine();
        SeriesModel s = app.findSeriesById(id);
        if (s != null) {
            System.out.println("Series found: " + s.seriesName + " | Age: " + s.seriesAge +
                    " | Episodes: " + s.seriesNumberOfEpisodes);
        } else {
            System.out.println("Series with Series Id: " + id + " was not found!");
        }
    }

    private static void updateSeries() {
        System.out.print("Enter Series ID to update: ");
        String id = scanner.nextLine();

        SeriesModel s = app.findSeriesById(id);
        if (s == null) {
            System.out.println("No series found with ID: " + id);
            return;
        }

        System.out.print("Enter new series name: ");
        String newName = scanner.nextLine();

        String newAge;
        while (true) {
            System.out.print("Enter new series age restriction: ");
            newAge = scanner.nextLine();
            if (app.validateAge(newAge)) {
                break;
            } else {
                System.out.println("Incorrect series age! Enter between 2 and 18.");
            }
        }

        String newEpisodes;
        while (true) {
            System.out.print("Enter new number of episodes: ");
            newEpisodes = scanner.nextLine();
            if (app.validateEpisodes(newEpisodes)) {
                break;
            } else {
                System.out.println("Invalid input. Please enter a number for episodes.");
            }
        }

        app.updateSeriesDetails(id, newName, newAge, newEpisodes);
        System.out.println("Series details updated successfully!");
    }

    private static void deleteSeries() {
        System.out.print("Enter Series ID to delete: ");
        String id = scanner.nextLine();
        boolean deleted = app.deleteSeries(id);
        if (deleted) {
            System.out.println("Series deleted successfully!");
        } else {
            System.out.println("No series found with ID: " + id);
        }
    }
}


