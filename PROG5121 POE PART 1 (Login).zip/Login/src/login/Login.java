package login;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;



public class Login {
    
    // Variables to store the registered username and password

    public static String registeredUsername = "";
    public static String registeredPassword = "";
   

    public static void main(String[] args) {

        UIManager.put("OptionPane.background", new Color(230, 240, 255));
        UIManager.put("Panel.background", new Color(230, 240, 255));
        UIManager.put("OptionPane.messageForeground", new Color(0, 51, 102));
        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 14));

        // Registration
        
        // Prompting the user to input their username
        String username = JOptionPane.showInputDialog("Enter username:");
        
        // Prompting the user to input their password
        String password = JOptionPane.showInputDialog("Enter password:");
        
        // Prompting the user to input their phoneNumber
        String phone = JOptionPane.showInputDialog("Enter phone number (+27...):");
        
        

        if (checkUsername(username)) {
            registeredUsername = username;
            JOptionPane.showMessageDialog(null, "Username successfully captured.");
        } else {
            return;
        }

        if (checkPasswordComplexity(password)) {
            registeredPassword = password;
            JOptionPane.showMessageDialog(null, "Password successfully captured.");
        } else {
            return;
        }

        if (checkCellPhoneNumber(phone)) {
            JOptionPane.showMessageDialog(null, "Cell phone number successfully added.");
        } else {
            return;
        }

        JOptionPane.showMessageDialog(null, "All details successfully captured. Proceeding to login...", "Success", JOptionPane.INFORMATION_MESSAGE);

        // Login
        String loginUsername = JOptionPane.showInputDialog("Enter username to login:");
        String loginPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (loginUsername.equals(registeredUsername) && loginPassword.equals(registeredPassword)) {
            JOptionPane.showMessageDialog(null, "Login successful. Welcome " + loginUsername + " It is great to see you again.");
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Username or password incorrect, please try again.");
            
        }
        
    }
    
    // Method to check if username is valid
    
    public static boolean checkUsername(String username) {
        if (!username.contains("_") || username.length() > 5) {
            JOptionPane.showMessageDialog(null,
                    "Username is not correctly formatted. Please ensure it contains an underscore and is no more than five characters long.",
                    "Invalid Username", JOptionPane.ERROR_MESSAGE);
            return false;
        }
        return true;
    }
    
    // Method to check if password meets complexity rules

    public static boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted,please ensure that the password contains at least eight characters,a capital letter,a number,and a special character.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!password.matches(".*[A-Z].*")) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted,please ensure that the password contains at least eight characters,a capital letter,a number,and a special character.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!password.matches(".*[0-9].*")) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted,please ensure that the password contains at least eight characters,a capital letter,a number,and a special character.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        if (!password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            JOptionPane.showMessageDialog(null, "Password is not correctly formatted,please ensure that the password contains at least eight characters,a capital letter,a number,and a special character.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return true;
    }
    
    // Method to check if phone number is in correct format

    public static boolean checkCellPhoneNumber(String phone) {
    if (!phone.matches("^\\+\\d{1,4}\\d{1,10}$")) {
        JOptionPane.showMessageDialog(null,
                "Cell phone number incorrectly formatted or does not contain international code,please correct the number and try again.",
                "Invalid Phone Number", JOptionPane.ERROR_MESSAGE);
        return false;
    }
    return true;
}

   
}


