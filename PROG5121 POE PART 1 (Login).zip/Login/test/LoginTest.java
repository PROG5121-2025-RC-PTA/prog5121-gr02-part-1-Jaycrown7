package login;


import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import org.junit.Test;


public class LoginTest {

  
    @Test
    public void testValidUsername() {
        assertTrue(Login.checkUsername("user_"));
    }

    @Test
    public void testInvalidUsername() {
        assertFalse(Login.checkUsername("user123"));
    }

    @Test
    public void testValidPassword() {
        assertTrue(Login.checkPasswordComplexity("Password1!"));
    }

    @Test
    public void testInvalidPassword() {
        assertFalse(Login.checkPasswordComplexity("pass"));
    }

    @Test
    public void testValidPhoneNumber() {
        assertTrue(Login.checkCellPhoneNumber("+27123456789"));
    }

    @Test
    public void testInvalidPhoneNumber() {
        assertFalse(Login.checkCellPhoneNumber("0712345678"));
    }
}

