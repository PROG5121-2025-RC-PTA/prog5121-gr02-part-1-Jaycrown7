package login;

import java.awt.Color;
import java.awt.Font;
import javax.swing.*;
import java.util.*;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.io.File;
import org.json.JSONArray;
import org.json.JSONObject;

public class Login {

    public static String registeredUsername = "";
    public static String registeredPassword = "";
    public static boolean isLoggedIn = false;
    
    // Arrays for different message types
    public static List<JSONObject> sentMessages = new ArrayList<>();
    public static List<JSONObject> disregardedMessages = new ArrayList<>();
    public static List<JSONObject> storedMessages = new ArrayList<>();
    public static List<String> messageHashes = new ArrayList<>();
    public static List<String> messageIDs = new ArrayList<>();
    
    public static int messageCount = 0;

    public static void main(String[] args) {

        UIManager.put("OptionPane.background", new Color(237, 240, 255));
        UIManager.put("Panel.background", new Color(230, 240, 255));
        UIManager.put("OptionPane.messageForeground", new Color(0, 51, 102));
        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 14));

        // Load existing stored messages from JSON file
        loadStoredMessages();

        // REGISTRATION
        String username = JOptionPane.showInputDialog("Enter username:");
        String password = JOptionPane.showInputDialog("Enter password:");
        String phone = JOptionPane.showInputDialog("Enter phone number (+27...):");

        if (!checkUsername(username)) return;
        registeredUsername = username;

        if (!checkPasswordComplexity(password)) return;
        registeredPassword = password;

        if (!checkCellPhoneNumber(phone)) return;

        JOptionPane.showMessageDialog(null, "All details successfully captured. Proceeding to login...");

        // LOGIN
        String loginUsername = JOptionPane.showInputDialog("Enter username to login:");
        String loginPassword = JOptionPane.showInputDialog("Enter password to login:");

        if (loginUsername.equals(registeredUsername) && loginPassword.equals(registeredPassword)) {
            isLoggedIn = true;
            JOptionPane.showMessageDialog(null, "Login successful. Welcome " + loginUsername + "!");
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Username or password incorrect.");
            return;
        }

        // MAIN MENU
        if (isLoggedIn) {
            JOptionPane.showMessageDialog(null, "Welcome to Quickchat");

            while (true) {
                String menuOption = JOptionPane.showInputDialog(
                        "Choose an option:\n" +
                        "1. Send messages\n" +
                        "2. Show recently sent messages\n" +
                        "3. Display sender and recipient of all sent messages\n" +
                        "4. Display longest sent message\n" +
                        "5. Search for message by ID\n" +
                        "6. Search messages by recipient\n" +
                        "7. Delete message by hash\n" +
                        "8. Display full message report\n" +
                        "9. Show message statistics\n" +
                        "10. Quit");

                if (menuOption == null) break;

                switch (menuOption) {
                    case "1":
                        sendMessages();
                        break;
                    case "2":
                        showRecentMessages();
                        break;
                    case "3":
                        displaySenderRecipient();
                        break;
                    case "4":
                        displayLongestMessage();
                        break;
                    case "5":
                        searchMessageById();
                        break;
                    case "6":
                        searchMessagesByRecipient();
                        break;
                    case "7":
                        deleteMessageByHash();
                        break;
                    case "8":
                        displayFullReport();
                        break;
                    case "9":
                        showStatistics();
                        break;
                    case "10":
                        JOptionPane.showMessageDialog(null, "Goodbye!");
                        return;
                    default:
                        JOptionPane.showMessageDialog(null, "Invalid option.");
                }
            }
        }
    }

    // VALIDATION METHODS
    public static boolean checkUsername(String username) {
        if (username == null || !username.contains("_") || username.length() > 5) {
            JOptionPane.showMessageDialog(null, "Username must contain _ and be max 5 characters.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Username successfully captured.");
        return true;
    }

    public static boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8 ||
                !password.matches(".*[A-Z].*") ||
                !password.matches(".*[0-9].*") ||
                !password.matches(".*[!@#$%^&*(),.?\":{}|<>].*")) {
            JOptionPane.showMessageDialog(null, "Password must be at least 8 characters and include uppercase, number, and special character.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Password successfully captured.");
        return true;
    }

    public static boolean checkCellPhoneNumber(String phone) {
        if (phone == null || !phone.matches("^\\+\\d{1,4}\\d{1,10}$")) {
            JOptionPane.showMessageDialog(null, "Phone number must start with country code like +27 and be valid.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Cell phone number successfully added.");
        return true;
    }

    public static boolean checkMessageId(String id) {
        return id != null && id.length() <= 10;
    }

    public static int checkRecipientCell(String cell) {
        if (cell != null && cell.length() == 10 && cell.startsWith("0")) {
            return 1;
        }
        return 0;
    }

    public static String createMessageHash(String message) {
        return Integer.toString(message.hashCode());
    }

    // ENHANCED MESSAGE HANDLING METHODS
    public static void sendMessages() {
        int toSend = 0;
        try {
            String input = JOptionPane.showInputDialog("How many messages do you want to send now?");
            if (input == null) return;
            toSend = Integer.parseInt(input);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Invalid number.");
            return;
        }

        for (int i = 0; i < toSend; i++) {
            String result = SentMessage();
            // Result handling is done inside SentMessage method
        }
    }

    public static String SentMessage() {
        String recipient = JOptionPane.showInputDialog("Enter recipient number (must start with 0):");
        if (recipient == null || checkRecipientCell(recipient) == 0) {
            JOptionPane.showMessageDialog(null, "Invalid recipient number.");
            return "fail";
        }

        String messageText = JOptionPane.showInputDialog("Enter your message:");
        if (messageText == null || messageText.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Message cannot be empty.");
            return "fail";
        }

        String messageID = UUID.randomUUID().toString().substring(0, 10);

        if (!checkMessageId(messageID)) {
            JOptionPane.showMessageDialog(null, "Message ID too long.");
            return "fail";
        }

        String[] options = {"Send Now", "Disregard", "Store for Later"};
        int choice = JOptionPane.showOptionDialog(null, "Choose:", "Message Option", JOptionPane.DEFAULT_OPTION,
                JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);

        if (choice == 0) {
            storeMessage(messageID, recipient, messageText, "sent");
            JOptionPane.showMessageDialog(null, "Message sent and saved.");
            return "sent";
        } else if (choice == 1) {
            storeMessage(messageID, recipient, messageText, "disregarded");
            JOptionPane.showMessageDialog(null, "Message disregarded.");
            return "disregarded";
        } else if (choice == 2) {
            storeMessage(messageID, recipient, messageText, "stored");
            JOptionPane.showMessageDialog(null, "Message stored for later.");
            return "stored";
        }

        return "fail";
    }

    public static void storeMessage(String id, String recipient, String message, String type) {
        JSONObject msg = new JSONObject();
        msg.put("id", id);
        msg.put("recipient", recipient);
        msg.put("message", message);
        msg.put("sender", registeredUsername);
        msg.put("timestamp", new Date().toString());
        String hash = createMessageHash(message);
        msg.put("hash", hash);
        msg.put("type", type);

        // Add to appropriate array based on type
        switch (type) {
            case "sent":
                sentMessages.add(msg);
                messageCount++;
                break;
            case "disregarded":
                disregardedMessages.add(msg);
                break;
            case "stored":
                storedMessages.add(msg);
                break;
        }

        // Add to hash and ID arrays
        messageHashes.add(hash);
        messageIDs.add(id);

        // Save to JSON files
        saveMessagesToFile();
    }

    public static void saveMessagesToFile() {
        // Save sent messages
        try (FileWriter file = new FileWriter("sent_messages.json")) {
            JSONArray jsonArray = new JSONArray(sentMessages);
            file.write(jsonArray.toString(4));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving sent messages: " + e.getMessage());
        }

        // Save disregarded messages
        try (FileWriter file = new FileWriter("disregarded_messages.json")) {
            JSONArray jsonArray = new JSONArray(disregardedMessages);
            file.write(jsonArray.toString(4));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving disregarded messages: " + e.getMessage());
        }

        // Save stored messages
        try (FileWriter file = new FileWriter("stored_messages.json")) {
            JSONArray jsonArray = new JSONArray(storedMessages);
            file.write(jsonArray.toString(4));
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error saving stored messages: " + e.getMessage());
        }
    }

    public static void loadStoredMessages() {
        // Load stored messages from JSON file
        File file = new File("stored_messages.json");
        if (file.exists()) {
            try (FileReader reader = new FileReader(file)) {
                StringBuilder content = new StringBuilder();
                int ch;
                while ((ch = reader.read()) != -1) {
                    content.append((char) ch);
                }
                
                if (content.length() > 0) {
                    JSONArray jsonArray = new JSONArray(content.toString());
                    for (int i = 0; i < jsonArray.length(); i++) {
                        JSONObject msg = jsonArray.getJSONObject(i);
                        storedMessages.add(msg);
                        messageHashes.add(msg.getString("hash"));
                        messageIDs.add(msg.getString("id"));
                    }
                }
            } catch (Exception e) {
                System.out.println("Error loading stored messages: " + e.getMessage());
            }
        }
    }

    // NEW FEATURE METHODS

    // a. Display sender and recipient of all sent messages
    public static void displaySenderRecipient() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }

        StringBuilder sb = new StringBuilder("SENDER AND RECIPIENT DETAILS:\n\n");
        for (JSONObject msg : sentMessages) {
            sb.append("Sender: ").append(msg.getString("sender"))
              .append(" → Recipient: ").append(msg.getString("recipient"))
              .append(" (ID: ").append(msg.getString("id")).append(")\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(500, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "Sender-Recipient Details", JOptionPane.INFORMATION_MESSAGE);
    }

    // b. Display the longest sent message
    public static void displayLongestMessage() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to analyze.");
            return;
        }

        JSONObject longestMsg = sentMessages.get(0);
        for (JSONObject msg : sentMessages) {
            if (msg.getString("message").length() > longestMsg.getString("message").length()) {
                longestMsg = msg;
            }
        }

        StringBuilder sb = new StringBuilder("LONGEST SENT MESSAGE:\n\n");
        sb.append("Message ID: ").append(longestMsg.getString("id")).append("\n");
        sb.append("To: ").append(longestMsg.getString("recipient")).append("\n");
        sb.append("Length: ").append(longestMsg.getString("message").length()).append(" characters\n");
        sb.append("Timestamp: ").append(longestMsg.getString("timestamp")).append("\n\n");
        sb.append("Message Content:\n").append(longestMsg.getString("message"));

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(500, 300));
        JOptionPane.showMessageDialog(null, scrollPane, "Longest Message", JOptionPane.INFORMATION_MESSAGE);
    }

    // c. Search for a message ID and display corresponding recipient and message
    public static void searchMessageById() {
        String searchId = JOptionPane.showInputDialog("Enter Message ID to search:");
        if (searchId == null || searchId.trim().isEmpty()) return;

        JSONObject foundMsg = null;
        String messageType = "";

        // Search in sent messages
        for (JSONObject msg : sentMessages) {
            if (msg.getString("id").equals(searchId)) {
                foundMsg = msg;
                messageType = "SENT";
                break;
            }
        }

        // Search in disregarded messages if not found
        if (foundMsg == null) {
            for (JSONObject msg : disregardedMessages) {
                if (msg.getString("id").equals(searchId)) {
                    foundMsg = msg;
                    messageType = "DISREGARDED";
                    break;
                }
            }
        }

        // Search in stored messages if not found
        if (foundMsg == null) {
            for (JSONObject msg : storedMessages) {
                if (msg.getString("id").equals(searchId)) {
                    foundMsg = msg;
                    messageType = "STORED";
                    break;
                }
            }
        }

        if (foundMsg != null) {
            StringBuilder sb = new StringBuilder("MESSAGE FOUND (" + messageType + "):\n\n");
            sb.append("Message ID: ").append(foundMsg.getString("id")).append("\n");
            sb.append("Recipient: ").append(foundMsg.getString("recipient")).append("\n");
            sb.append("Sender: ").append(foundMsg.getString("sender")).append("\n");
            sb.append("Timestamp: ").append(foundMsg.getString("timestamp")).append("\n");
            sb.append("Hash: ").append(foundMsg.getString("hash")).append("\n\n");
            sb.append("Message:\n").append(foundMsg.getString("message"));

            JTextArea textArea = new JTextArea(sb.toString());
            textArea.setEditable(false);
            textArea.setWrapStyleWord(true);
            textArea.setLineWrap(true);
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new java.awt.Dimension(500, 300));
            JOptionPane.showMessageDialog(null, scrollPane, "Message Search Result", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(null, "Message ID not found: " + searchId);
        }
    }

    // d. Search for all messages sent to a particular recipient
    public static void searchMessagesByRecipient() {
        String searchRecipient = JOptionPane.showInputDialog("Enter recipient number to search:");
        if (searchRecipient == null || searchRecipient.trim().isEmpty()) return;

        List<JSONObject> foundMessages = new ArrayList<>();

        // Search in all message types
        for (JSONObject msg : sentMessages) {
            if (msg.getString("recipient").equals(searchRecipient)) {
                foundMessages.add(msg);
            }
        }
        for (JSONObject msg : disregardedMessages) {
            if (msg.getString("recipient").equals(searchRecipient)) {
                foundMessages.add(msg);
            }
        }
        for (JSONObject msg : storedMessages) {
            if (msg.getString("recipient").equals(searchRecipient)) {
                foundMessages.add(msg);
            }
        }

        if (foundMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + searchRecipient);
            return;
        }

        StringBuilder sb = new StringBuilder("MESSAGES FOR RECIPIENT: " + searchRecipient + "\n");
        sb.append("Total messages found: ").append(foundMessages.size()).append("\n\n");

        for (JSONObject msg : foundMessages) {
            sb.append("ID: ").append(msg.getString("id"))
              .append(" | Type: ").append(msg.getString("type").toUpperCase())
              .append(" | Time: ").append(msg.getString("timestamp")).append("\n");
            sb.append("Message: ").append(msg.getString("message")).append("\n");
            sb.append("Hash: ").append(msg.getString("hash")).append("\n\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(600, 400));
        JOptionPane.showMessageDialog(null, scrollPane, "Messages by Recipient", JOptionPane.INFORMATION_MESSAGE);
    }

    // e. Delete a message using the message hash
    public static void deleteMessageByHash() {
        String searchHash = JOptionPane.showInputDialog("Enter message hash to delete:");
        if (searchHash == null || searchHash.trim().isEmpty()) return;

        boolean found = false;
        String messageType = "";

        // Search and remove from sent messages
        for (int i = 0; i < sentMessages.size(); i++) {
            if (sentMessages.get(i).getString("hash").equals(searchHash)) {
                JSONObject msg = sentMessages.remove(i);
                messageType = "SENT";
                found = true;
                messageCount--;
                break;
            }
        }

        // Search and remove from disregarded messages
        if (!found) {
            for (int i = 0; i < disregardedMessages.size(); i++) {
                if (disregardedMessages.get(i).getString("hash").equals(searchHash)) {
                    JSONObject msg = disregardedMessages.remove(i);
                    messageType = "DISREGARDED";
                    found = true;
                    break;
                }
            }
        }

        // Search and remove from stored messages
        if (!found) {
            for (int i = 0; i < storedMessages.size(); i++) {
                if (storedMessages.get(i).getString("hash").equals(searchHash)) {
                    JSONObject msg = storedMessages.remove(i);
                    messageType = "STORED";
                    found = true;
                    break;
                }
            }
        }

        if (found) {
            // Remove from hash and ID arrays
            messageHashes.remove(searchHash);
            
            // Save updated data to files
            saveMessagesToFile();
            
            JOptionPane.showMessageDialog(null, "Message deleted successfully!\nType: " + messageType + "\nHash: " + searchHash);
        } else {
            JOptionPane.showMessageDialog(null, "Message hash not found: " + searchHash);
        }
    }

    // f. Display a report that lists the full details of sent messages
    public static void displayFullReport() {
        StringBuilder report = new StringBuilder();
        report.append("=== QUICKCHAT MESSAGE REPORT ===\n\n");
        report.append("Generated on: ").append(new Date()).append("\n");
        report.append("User: ").append(registeredUsername).append("\n\n");

        // Summary statistics
        report.append("SUMMARY STATISTICS:\n");
        report.append("- Sent Messages: ").append(sentMessages.size()).append("\n");
        report.append("- Disregarded Messages: ").append(disregardedMessages.size()).append("\n");
        report.append("- Stored Messages: ").append(storedMessages.size()).append("\n");
        report.append("- Total Messages: ").append(sentMessages.size() + disregardedMessages.size() + storedMessages.size()).append("\n\n");

        // Sent Messages Details
        if (!sentMessages.isEmpty()) {
            report.append("=== SENT MESSAGES DETAILS ===\n\n");
            for (int i = 0; i < sentMessages.size(); i++) {
                JSONObject msg = sentMessages.get(i);
                report.append("Message #").append(i + 1).append(":\n");
                report.append("  ID: ").append(msg.getString("id")).append("\n");
                report.append("  Sender: ").append(msg.getString("sender")).append("\n");
                report.append("  Recipient: ").append(msg.getString("recipient")).append("\n");
                report.append("  Timestamp: ").append(msg.getString("timestamp")).append("\n");
                report.append("  Hash: ").append(msg.getString("hash")).append("\n");
                report.append("  Message Length: ").append(msg.getString("message").length()).append(" characters\n");
                report.append("  Content: ").append(msg.getString("message")).append("\n\n");
            }
        }

        // Disregarded Messages
        if (!disregardedMessages.isEmpty()) {
            report.append("=== DISREGARDED MESSAGES ===\n\n");
            for (int i = 0; i < disregardedMessages.size(); i++) {
                JSONObject msg = disregardedMessages.get(i);
                report.append("Disregarded #").append(i + 1).append(":\n");
                report.append("  ID: ").append(msg.getString("id")).append("\n");
                report.append("  Recipient: ").append(msg.getString("recipient")).append("\n");
                report.append("  Content: ").append(msg.getString("message")).append("\n\n");
            }
        }

        // Stored Messages
        if (!storedMessages.isEmpty()) {
            report.append("=== STORED MESSAGES (FOR LATER) ===\n\n");
            for (int i = 0; i < storedMessages.size(); i++) {
                JSONObject msg = storedMessages.get(i);
                report.append("Stored #").append(i + 1).append(":\n");
                report.append("  ID: ").append(msg.getString("id")).append("\n");
                report.append("  Recipient: ").append(msg.getString("recipient")).append("\n");
                report.append("  Content: ").append(msg.getString("message")).append("\n\n");
            }
        }

        // Display the report
        JTextArea textArea = new JTextArea(report.toString());
        textArea.setEditable(false);
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 11));
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(700, 500));
        JOptionPane.showMessageDialog(null, scrollPane, "Full Message Report", JOptionPane.INFORMATION_MESSAGE);
    }

    // Additional utility methods
    public static void showRecentMessages() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No messages sent yet.");
            return;
        }

        StringBuilder sb = new StringBuilder("RECENTLY SENT MESSAGES:\n\n");
        for (JSONObject msg : sentMessages) {
            sb.append("To: ").append(msg.getString("recipient"))
              .append(" | ID: ").append(msg.getString("id"))
              .append(" | Time: ").append(msg.getString("timestamp")).append("\n");
            sb.append("Message: ").append(msg.getString("message")).append("\n");
            sb.append("Hash: ").append(msg.getString("hash")).append("\n\n");
        }

        JTextArea textArea = new JTextArea(sb.toString());
        textArea.setEditable(false);
        textArea.setWrapStyleWord(true);
        textArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new java.awt.Dimension(600, 400));
        JOptionPane.showMessageDialog(null, scrollPane, "Recent Messages", JOptionPane.INFORMATION_MESSAGE);
    }

    public static void showStatistics() {
        StringBuilder stats = new StringBuilder("MESSAGE STATISTICS:\n\n");
        
        stats.append("Total Messages: ").append(sentMessages.size() + disregardedMessages.size() + storedMessages.size()).append("\n");
        stats.append("Sent Messages: ").append(sentMessages.size()).append("\n");
        stats.append("Disregarded Messages: ").append(disregardedMessages.size()).append("\n");
        stats.append("Stored Messages: ").append(storedMessages.size()).append("\n\n");
        
        stats.append("Unique Recipients: ").append(getUniqueRecipients()).append("\n");
        stats.append("Total Message Hashes: ").append(messageHashes.size()).append("\n");
        stats.append("Total Message IDs: ").append(messageIDs.size()).append("\n\n");
        
        if (!sentMessages.isEmpty()) {
            int totalChars = 0;
            for (JSONObject msg : sentMessages) {
                totalChars += msg.getString("message").length();
            }
            stats.append("Average Message Length: ").append(totalChars / sentMessages.size()).append(" characters\n");
        }
        
        JOptionPane.showMessageDialog(null, stats.toString(), "Statistics", JOptionPane.INFORMATION_MESSAGE);
    }

    private static int getUniqueRecipients() {
        Set<String> recipients = new HashSet<>();
        for (JSONObject msg : sentMessages) {
            recipients.add(msg.getString("recipient"));
        }
        for (JSONObject msg : disregardedMessages) {
            recipients.add(msg.getString("recipient"));
        }
        for (JSONObject msg : storedMessages) {
            recipients.add(msg.getString("recipient"));
        }
        return recipients.size();
    }

    public static String printMessages() {
        if (sentMessages.isEmpty()) return "No messages sent yet.";
        StringBuilder sb = new StringBuilder();
        for (JSONObject msg : sentMessages) {
            sb.append("To: ").append(msg.getString("recipient"))
              .append("\nMessage: ").append(msg.getString("message"))
              .append("\nHash: ").append(msg.getString("hash")).append("\n\n");
        }
        return sb.toString();
    }

    public static int returnTotalMessages() {
        return messageCount;
    }
}



