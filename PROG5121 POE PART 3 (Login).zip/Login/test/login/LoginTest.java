package login;

import org.junit.Test;
import static org.junit.Assert.*;


public class LoginTest {

    @Test
    public void testCheckUsername() {
        assertTrue(Login.checkUsername("ab_cd")); // valid
        assertFalse(Login.checkUsername("abcde")); // no underscore
        assertFalse(Login.checkUsername("abcdef_")); // too long
    }

    @Test
    public void testCheckPasswordComplexity() {
        assertTrue(Login.checkPasswordComplexity("Abcdef1!")); // valid
        assertFalse(Login.checkPasswordComplexity("abcdefg")); // no capital, number, or special char
        assertFalse(Login.checkPasswordComplexity("Abcdefgh")); // no number or special char
        assertFalse(Login.checkPasswordComplexity("Abcd1234")); // no special char
    }

    @Test
    public void testCheckCellPhoneNumber() {
        assertTrue(Login.checkCellPhoneNumber("+27821234567")); // valid
        assertFalse(Login.checkCellPhoneNumber("0821234567")); // no +
        assertFalse(Login.checkCellPhoneNumber("+123")); // too short
    }

    @Test
    public void testCheckMessageId() {
        assertTrue(Login.checkMessageId("123456789")); // valid
        assertFalse(Login.checkMessageId("12345678901")); // 11 characters
    }

    

    @Test
    public void testCreateMessageHash() {
        String msg = "Hello";
        int expectedHash = msg.hashCode();
        String hash = Login.createMessageHash(msg);
        assertEquals(String.valueOf(expectedHash), hash);
    }

    @Test
    public void testSentMessage() {
        
        assertTrue(true);
    }

    @Test
    public void testStoreMessage() {
        
        assertTrue(true);
    }

    @Test
    public void testPrintMessages() {
        String output = Login.printMessages();
        assertNotNull(output); // should return a string
    }

    @Test
    public void testReturnTotalMessages() {
        int count = Login.returnTotalMessages();
        assertTrue(count >= 0); 
    }
}

